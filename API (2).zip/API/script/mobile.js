function calc(){
    
    var peso = parseInt(document.getElementById("peso").value);
    var Altura = parseInt(document.getElementById("altura").value);
    var imc= peso*Altura^2;

    if (peso <= 0 || altura <= 0) {
        alert("Peso e altura devem ser valores positivos e maiores que zero.");
    } else 
        
       
        alert("O seu IMC é: " + imc);

        {if( imc < 18.5)
        alert("baixo peso");}
        
        if (imc >= 18.5 && imc < 24.99) {
        alert("peso normal.");
    }   else if (imc >= 25 && imc < 29.99) {
        alert("sobrepeso.");
    }   else if (imc >= 30 )
        alert("obesidade."); 
   
}
